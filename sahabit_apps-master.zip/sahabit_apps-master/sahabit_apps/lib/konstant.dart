// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

Color primaryColor = Color(0xFF050522);
// String sUrl = "kutikin.000webhostapp.com";
String sUrl = "192.168.100.89";
